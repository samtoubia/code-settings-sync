**Visual Studio Code Version :** [ VERSION_HERE ]
**Code Settings Sync Version :** [ VERSION_HERE ]
**Operating System :** [ VERSION_HERE ]
**Occurs On:** [Upload / Download / Help Configuring ]
**Proxy Enabled:** [ Yes / No ]
**GIst Id:** [ ID_HERE ]

I have posted frequently asked questions on 
http://shanalikhan.github.io/2016/11/07/visual-studio-code-frequently-asked-questions.html 
so you may able to resolve the error quickly. 
Please make sure to write the versions and console logged error picture or copied text

