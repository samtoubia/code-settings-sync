export enum OsType {
    Windows = 1,
    Linux ,
    Mac
};

export enum SettingType{
    Settings = 1,
    Launch ,
    KeyBindings,
    Locale,
    Extensions
};